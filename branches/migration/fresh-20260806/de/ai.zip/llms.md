# de.medizininformatikinitiative.kerndatensatz.dokument#2026.0.1: MII IG Dokument(de)

## Pages

* [Startseite](index.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Übersetzungshinweise](translationinfo.md)
* [Artefaktübersicht](artifacts.md)
* [Anleitung](guidance.md)
* [Must-Support](must-support.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Konformität](conformance.md)
* [Änderungshistorie](changes.md)
* [Logische Modelle](logical-models.md)
* [UML-Diagramme](uml-diagrams.md)
* [Downloads](downloads.md)
* [Allgemeine Anforderungen](general-requirements.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Metadaten](metadata.md)
* [Umgang mit fehlenden Daten](missing-data.md)
* [Suchparameter und Operationen](search-parameters-and-operations.md)
* [Datensätze und Beschreibungen](datasets-and-descriptions.md)
* [Beispiele](examples.md)
* [CapabilityStatements](capability-statements.md)
* [Versionierung](version-history.md)
* [Terminologie](terminology.md)
* [Profile und Extensions](profiles-and-extensions.md)

## Resources

### CodeSystems

* [MII VS Dokument NLP Processing Status](CodeSystem-mii-cs-dokument-nlp-processing-status.md)

### ValueSets

* [MII VS Dokument Einrichtungart](ValueSet-mii-vs-dokument-einrichtungsart.md)
* [MII VS Dokument Fachgebiet](ValueSet-mii-vs-dokument-fachgebiet.md)
* [MII VS Dokument Format Code](ValueSet-mii-vs-dokument-format-code.md)
* [MII VS Dokument NLP Processing Status](ValueSet-mii-vs-dokument-nlp-processing-status.md)
* [MII VS Dokument SCT Dokument Kategorie](ValueSet-mii-vs-dokument-sct-dokument-kategorie.md)
* [MII VS Dokument SCT Dokument Typ](ValueSet-mii-vs-dokument-sct-dokument-typ.md)

### Logicals

* [MII LM Dokument](StructureDefinition-mii-lm-dokument.md)

### Resource Profiles

* [MII PR Dokument Dokument](StructureDefinition-mii-pr-dokument-dokument.md)

### Extensions

* [MII EX Dokument NLP Processing Status](StructureDefinition-mii-ex-dokument-nlp-processing-status.md)

### CapabilityStatements

* [MII CPS Dokument CapabilityStatement](CapabilityStatement-mii-cps-dokument-capabilitystatement.md)

### ImplementationGuides

* [MII IG Dokument](ImplementationGuide-mii-ig-dokument.md)

### Parameters

* [mii-param-dokument-manifest](Parameters-mii-param-dokument-manifest.md)

### Examples

* [AmandaAlzheimerAnnotiertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerAnnotiertesDokument.md)
* [AmandaAlzheimerDeIdentifiziertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerDeIdentifiziertesDokument.md)
* [AmandaAlzheimerOriginalDokument (DocumentReference)](DocumentReference-AmandaAlzheimerOriginalDokument.md)
* [AmandaAlzheimerAbteilungskontakt (Encounter)](Encounter-AmandaAlzheimerAbteilungskontakt.md)
* [AmandaAlzheimerEinrichtungskontakt (Encounter)](Encounter-AmandaAlzheimerEinrichtungskontakt.md)
* [AmandaAlzheimerVersorgungsstellenKontakt (Encounter)](Encounter-AmandaAlzheimerVersorgungsstellenKontakt.md)
* [AmandaAlzheimer (Patient)](Patient-AmandaAlzheimer.md)
