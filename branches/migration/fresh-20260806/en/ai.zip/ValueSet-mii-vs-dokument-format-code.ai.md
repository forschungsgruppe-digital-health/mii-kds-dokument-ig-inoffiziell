# MII VS Dokument Format Code - MII IG Dokument v2026.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Dokument Format Code**

## ValueSet: MII VS Dokument Format Code 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-format-code | *Version*:2026.0.1 |
| Active as of 2026-08-06 | *Computable Name*:MII_VS_Dokument_Format_Code |

 
ValueSet zum (komplexen) Format Code eines Dokuments 

 **References** 

* [MII PR Dokument Dokument](StructureDefinition-mii-pr-dokument-dokument.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-dokument-format-code",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "de-DE",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-dokument/ValueSet/mii-vs-dokument-format-code",
  "version" : "2026.0.1",
  "name" : "MII_VS_Dokument_Format_Code",
  "title" : "MII VS Dokument Format Code",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-06T18:49:07+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "ValueSet zum (komplexen) Format Code eines Dokuments",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "276"
    }]
  }],
  "compose" : {
    "include" : [{
      "valueSet" : ["http://ihe.net/fhir/ihe.formatcode.fhir/ValueSet/formatcode"]
    },
    {
      "valueSet" : ["http://ihe-d.de/ValueSets/IHEXDSformatCodeDE"]
    }]
  }
}

```
