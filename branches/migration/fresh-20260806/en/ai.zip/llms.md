# de.medizininformatikinitiative.kerndatensatz.dokument#2026.0.1: MII IG Dokument(en)

## Pages

* [Home](index.md)
* [Researcher Guidance](researcher-guidance.md)
* [Translationinfo](translationinfo.md)
* [Artifacts Summary](artifacts.md)
* [Guidance](guidance.md)
* [Must Support](must-support.md)
* [Implementer Guidance](implementer-guidance.md)
* [Conformance](conformance.md)
* [Changes](changes.md)
* [Logical Models](logical-models.md)
* [Uml Diagrams](uml-diagrams.md)
* [Downloads](downloads.md)
* [General Requirements](general-requirements.md)
* [Security and Privacy](security-and-privacy.md)
* [Metadata](metadata.md)
* [Missing Data](missing-data.md)
* [Search Parameters and Operations](search-parameters-and-operations.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Examples](examples.md)
* [Capability Statements](capability-statements.md)
* [Version History](version-history.md)
* [Terminology](terminology.md)
* [Profiles and Extensions](profiles-and-extensions.md)

## Resources

### CodeSystems

* [MII VS Dokument NLP Processing Status](CodeSystem-mii-cs-dokument-nlp-processing-status.md)

### ValueSets

* [MII VS Dokument Einrichtungart](ValueSet-mii-vs-dokument-einrichtungsart.md)
* [MII VS Dokument Fachgebiet](ValueSet-mii-vs-dokument-fachgebiet.md)
* [MII VS Dokument Format Code](ValueSet-mii-vs-dokument-format-code.md)
* [MII VS Dokument NLP Processing Status](ValueSet-mii-vs-dokument-nlp-processing-status.md)
* [MII VS Dokument SCT Dokument Kategorie](ValueSet-mii-vs-dokument-sct-dokument-kategorie.md)
* [MII VS Dokument SCT Dokument Typ](ValueSet-mii-vs-dokument-sct-dokument-typ.md)

### Logicals

* [MII LM Dokument](StructureDefinition-mii-lm-dokument.md)

### Resource Profiles

* [MII PR Dokument Dokument](StructureDefinition-mii-pr-dokument-dokument.md)

### Extensions

* [MII EX Dokument NLP Processing Status](StructureDefinition-mii-ex-dokument-nlp-processing-status.md)

### CapabilityStatements

* [MII CPS Dokument CapabilityStatement](CapabilityStatement-mii-cps-dokument-capabilitystatement.md)

### ImplementationGuides

* [MII IG Dokument](ImplementationGuide-mii-ig-dokument.md)

### Parameters

* [mii-param-dokument-manifest](Parameters-mii-param-dokument-manifest.md)

### Examples

* [AmandaAlzheimerAnnotiertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerAnnotiertesDokument.md)
* [AmandaAlzheimerDeIdentifiziertesDokument (DocumentReference)](DocumentReference-AmandaAlzheimerDeIdentifiziertesDokument.md)
* [AmandaAlzheimerOriginalDokument (DocumentReference)](DocumentReference-AmandaAlzheimerOriginalDokument.md)
* [AmandaAlzheimerAbteilungskontakt (Encounter)](Encounter-AmandaAlzheimerAbteilungskontakt.md)
* [AmandaAlzheimerEinrichtungskontakt (Encounter)](Encounter-AmandaAlzheimerEinrichtungskontakt.md)
* [AmandaAlzheimerVersorgungsstellenKontakt (Encounter)](Encounter-AmandaAlzheimerVersorgungsstellenKontakt.md)
* [AmandaAlzheimer (Patient)](Patient-AmandaAlzheimer.md)
